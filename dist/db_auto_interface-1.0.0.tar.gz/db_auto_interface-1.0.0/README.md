# DB Auto Interface

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

**Автоматический генератор desktop интерфейса для PostgreSQL баз данных**

Библиотека создает полнофункциональный графический интерфейс для работы с любыми таблицами PostgreSQL БД без необходимости написания кода. Все определяется автоматически на основе структуры базы данных.

## 🚀 Возможности

- 🔍 **Автоматический анализ схемы БД** - автоматически определяет структуру таблиц, связи и типы данных
- 🧭 **Навигация между таблицами** - автоматическое построение карты переходов между связанными таблицами
- ✏️ **CRUD операции** - создание, чтение, обновление и удаление записей
- 📝 **Динамические формы** - автоматическое создание форм редактирования на основе структуры таблиц
- 🔎 **Поиск и фильтрация** - встроенный поиск по данным
- 📄 **Пагинация** - эффективная работа с большими таблицами
- 🎨 **Современный UI** - интерфейс на основе tkinter/ttk
- 🔗 **Работа с внешними ключами** - автоматические комбобоксы для связанных таблиц

## 📋 Требования

- Python 3.8 или выше
- PostgreSQL база данных
- psycopg2-binary (устанавливается автоматически)

## 💾 Установка

### Установка из PyPI (когда опубликована)

```bash
pip install db-auto-interface
```

### Установка из исходников

```bash
# Клонируйте репозиторий или распакуйте архив
cd db_auto_interface_package

# Установите библиотеку
pip install .

# Или в режиме разработки
pip install -e .
```

### Установка из локального архива

```bash
# Создайте архив
python setup.py sdist bdist_wheel

# Установите из архива
pip install dist/db-auto-interface-1.0.0.tar.gz
```

## 🎯 Быстрый старт

### Простой пример

```python
from db_auto_interface import DBAutoInterface

# Параметры подключения
connection_params = {
    'host': 'localhost',
    'database': 'your_database',
    'user': 'postgres',
    'password': 'your_password',
    'port': 5432
}

# Создаем и запускаем приложение
app = DBAutoInterface(connection_params=connection_params)
app.run()
```

### Расширенный пример

```python
from db_auto_interface import UniversalDB, DBAutoInterface

# Создание подключения
db = UniversalDB()
db.connect({
    'host': 'localhost',
    'database': 'my_db',
    'user': 'postgres',
    'password': 'password'
})

# Анализ схемы
schema = db.get_schema()
print(f"Найдено таблиц: {len(schema)}")

# Запуск интерфейса
app = DBAutoInterface(db_connection=db)
app.run()
```

### Использование из командной строки

После установки библиотеки доступна консольная команда:

```bash
# Установите переменные окружения
export DB_HOST=localhost
export DB_NAME=my_database
export DB_USER=postgres
export DB_PASSWORD=password

# Запустите приложение
db-auto-interface
```

## 📁 Структура проекта

```
db_auto_interface/
├── __init__.py              # Экспорт основных классов
├── core/                    # Ядро библиотеки
│   ├── db_schema.py         # Анализатор схемы БД
│   ├── universal_db.py      # Универсальный класс для работы с БД
│   └── navigation.py        # Система навигации между таблицами
├── ui/                      # Графический интерфейс
│   ├── main_app.py          # Главное приложение
│   ├── table_view.py        # Виджет просмотра таблиц
│   ├── record_form.py       # Формы редактирования
│   └── widgets.py           # Дополнительные виджеты
└── utils/                   # Утилиты
```

## 📖 Документация

Подробная документация доступна в репозитории проекта:
- Примеры использования
- API документация
- Руководство разработчика

## 🧪 Тестирование

```bash
# Запуск тестов
python -m pytest tests/ -v
```

## 📦 Использование в других проектах

### Установка как зависимость

```python
# В setup.py вашего проекта
install_requires=[
    'db-auto-interface>=1.0.0',
]
```

### Импорт в коде

```python
from db_auto_interface import DBAutoInterface, UniversalDB

# Использование...
```

## 🔧 Основные компоненты

### UniversalDB

Универсальный класс для работы с базой данных:

```python
from db_auto_interface import UniversalDB

db = UniversalDB()
db.connect({
    'host': 'localhost',
    'database': 'test_db',
    'user': 'postgres',
    'password': 'password'
})

# Получение схемы
schema = db.get_schema()

# Получение данных таблицы с пагинацией
data = db.get_table_data('users', page=1, page_size=50)

# CRUD операции
db.insert_record('users', {'name': 'John', 'email': 'john@example.com'})
db.update_record('users', user_id, {'name': 'Jane'})
db.delete_record('users', user_id)
```

### DBAutoInterface

Главное приложение с графическим интерфейсом:

```python
from db_auto_interface import DBAutoInterface

app = DBAutoInterface(connection_params={
    'host': 'localhost',
    'database': 'test_db',
    'user': 'postgres',
    'password': 'password'
})
app.run()
```

## 💡 Особенности

### Автоматическое определение схемы

Библиотека автоматически анализирует структуру базы данных:
- Определяет все таблицы
- Анализирует столбцы и их типы
- Находит первичные и внешние ключи
- Строит карту связей между таблицами

### Навигация между таблицами

Автоматически определяет:
- **Точки входа** - таблицы без входящих ссылок
- **Связующие таблицы** - таблицы с внешними ключами
- **Последовательность заполнения** - оптимальный порядок создания записей
- **Циклические зависимости** - обнаружение циклов в схеме

### Динамические формы

Формы автоматически создаются на основе структуры таблицы:
- Текстовые поля для строк
- Числовые поля для чисел
- Комбобоксы для внешних ключей
- Чекбоксы для boolean значений
- Текстовые области для больших текстов

### Валидация данных

Автоматическая валидация на основе типов данных PostgreSQL:
- Проверка обязательных полей
- Валидация типов данных
- Проверка ограничений

## ⌨️ Горячие клавиши

- `Ctrl+S` - Сохранить изменения
- `Ctrl+F` - Поиск
- `F5` - Обновить таблицу
- `Ctrl+R` - Обновить схему
- `Ctrl+Q` - Выход

## 📝 Лицензия

MIT License - см. файл `LICENSE`

## 🤝 Поддержка

Для вопросов и предложений создавайте issues в репозитории проекта.

## 📚 Дополнительные ресурсы

- **Архитектура:** См. документацию в репозитории
- **Примеры:** См. примеры в репозитории
- **Тесты:** `tests/` в репозитории

